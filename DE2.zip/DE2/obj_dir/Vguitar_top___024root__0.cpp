// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vguitar_top.h for the primary calling header

#include "Vguitar_top__pch.h"

void Vguitar_top___024root___eval_sample(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_sample\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__ico(const ::VlUnpacked<::QData/*63:0*/, 2> &triggers, const ::std::string &tag);
#endif  // VL_DEBUG
bool Vguitar_top___024root___trigger_anySet__ico(const ::VlUnpacked<::QData/*63:0*/, 2> &in);

bool Vguitar_top___024root___eval_ico(Vguitar_top___024root* vlSelf, ::CData/*0:0*/ firstIteration) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_ico\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    ::CData/*0:0*/ __VicoExecute;
    // Body
    vlSelfRef.__VicoTriggered[1U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VicoTriggered[1U]) 
                                     | (::IData)((::IData)(firstIteration)));
    {
        // Inlined CFunc: _eval_triggers_vec__ico
        vlSelfRef.__VicoTriggered[0U] = (::QData)((::IData)(
                                                            ((((::IData)(vlSelfRef.__VprimaryPorts.strum_down) 
                                                               != (::IData)(vlSelfRef.__Vtrigprevexpr___TOP__strum_down__0)) 
                                                              << 4U) 
                                                             | (((((::IData)(vlSelfRef.__VprimaryPorts.strum_up) 
                                                                   != (::IData)(vlSelfRef.__Vtrigprevexpr___TOP__strum_up__0)) 
                                                                  << 3U) 
                                                                 | (((::IData)(vlSelfRef.__VprimaryPorts.fret) 
                                                                     != (::IData)(vlSelfRef.__Vtrigprevexpr___TOP__fret__0)) 
                                                                    << 2U)) 
                                                                | ((((::IData)(vlSelfRef.__VprimaryPorts.rst) 
                                                                     != (::IData)(vlSelfRef.__Vtrigprevexpr___TOP__rst__0)) 
                                                                    << 1U) 
                                                                   | ((::IData)(vlSelfRef.__VprimaryPorts.clk50) 
                                                                      != (::IData)(vlSelfRef.__Vtrigprevexpr___TOP__clk50__0)))))));
        vlSelfRef.__Vtrigprevexpr___TOP__clk50__0 = vlSelfRef.__VprimaryPorts.clk50;
        vlSelfRef.__Vtrigprevexpr___TOP__rst__0 = vlSelfRef.__VprimaryPorts.rst;
        vlSelfRef.__Vtrigprevexpr___TOP__fret__0 = vlSelfRef.__VprimaryPorts.fret;
        vlSelfRef.__Vtrigprevexpr___TOP__strum_up__0 
            = vlSelfRef.__VprimaryPorts.strum_up;
        vlSelfRef.__Vtrigprevexpr___TOP__strum_down__0 
            = vlSelfRef.__VprimaryPorts.strum_down;
        if (VL_UNLIKELY(((1U & (~ (::IData)(vlSelfRef.__VicoDidInit)))))) {
            vlSelfRef.__VicoDidInit = 1U;
            vlSelfRef.__VicoTriggered[0U] = (1ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (2ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (4ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (8ULL | vlSelfRef.__VicoTriggered[0U]);
            vlSelfRef.__VicoTriggered[0U] = (0x0000000000000010ULL 
                                             | vlSelfRef.__VicoTriggered[0U]);
        }
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vguitar_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
    }
#endif
    __VicoExecute = Vguitar_top___024root___trigger_anySet__ico(vlSelfRef.__VicoTriggered);
    if (__VicoExecute) {
        {
            // Inlined CFunc: _eval_body__ico
            if ((((4ULL & vlSelfRef.__VicoTriggered[0U])) != 0ULL)) {
                {
                    // Inlined CFunc: _ico_comb__TOP__0
                    ::CData/*0:0*/ __Vinline_0__eval_body__ico___Vinline_0__ico_comb__TOP__0___Vdfg_Regularize_1117;
                    __Vinline_0__eval_body__ico___Vinline_0__ico_comb__TOP__0___Vdfg_Regularize_1117 = 0;
                    vlSelfRef.guitar_top__DOT__hit_unit__DOT__fret_match 
                        = (((::IData)(vlSelfRef.__VprimaryPorts.fret) 
                            == (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone)) 
                           & (0U != (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone)));
                    __Vinline_0__eval_body__ico___Vinline_0__ico_comb__TOP__0___Vdfg_Regularize_1117 
                        = ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__in_highway) 
                           & ((0x01c0U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                              & (((4U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)) 
                                  && (1U & ((::IData)(vlSelfRef.__VprimaryPorts.fret) 
                                            >> (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)))) 
                                 & (0x0180U <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)))));
                    vlSelfRef.__VprimaryPorts.r = (0x000000ffU 
                                                   & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                      & (((::IData)(__Vinline_0__eval_body__ico___Vinline_0__ico_comb__TOP__0___Vdfg_Regularize_1117)
                                                           ? 
                                                          ((::IData)(vlSelfRef.__Vdfg_Regularize_1139) 
                                                           | (- (::IData)(
                                                                          (1U 
                                                                           & ((::IData)(vlSelfRef.__Vdfg_Regularize_1139) 
                                                                              >> 8U)))))
                                                           : (::IData)(vlSelfRef.__Vdfg_Regularize_1134)) 
                                                         | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
                    vlSelfRef.__VprimaryPorts.g = (0x000000ffU 
                                                   & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                      & (((::IData)(__Vinline_0__eval_body__ico___Vinline_0__ico_comb__TOP__0___Vdfg_Regularize_1117)
                                                           ? 
                                                          ((::IData)(vlSelfRef.__Vdfg_Regularize_1137) 
                                                           | (- (::IData)(
                                                                          (1U 
                                                                           & ((::IData)(vlSelfRef.__Vdfg_Regularize_1137) 
                                                                              >> 8U)))))
                                                           : (::IData)(vlSelfRef.__Vdfg_Regularize_1135)) 
                                                         | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
                    vlSelfRef.__VprimaryPorts.b = (0x000000ffU 
                                                   & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                      & (((::IData)(__Vinline_0__eval_body__ico___Vinline_0__ico_comb__TOP__0___Vdfg_Regularize_1117)
                                                           ? 
                                                          ((::IData)(vlSelfRef.__Vdfg_Regularize_1138) 
                                                           | (- (::IData)(
                                                                          (1U 
                                                                           & ((::IData)(vlSelfRef.__Vdfg_Regularize_1138) 
                                                                              >> 8U)))))
                                                           : (::IData)(vlSelfRef.__Vdfg_Regularize_1136)) 
                                                         | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
                }
            }
            if ((((0x0000000000000018ULL & vlSelfRef.__VicoTriggered[0U])) != 0ULL)) {
                {
                    // Inlined CFunc: _ico_comb__TOP__1
                    vlSelfRef.guitar_top__DOT__hit_unit__DOT__raw_strum 
                        = ((::IData)(vlSelfRef.__VprimaryPorts.strum_up) 
                           | (::IData)(vlSelfRef.__VprimaryPorts.strum_down));
                }
            }
        }
    }
    return (__VicoExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__act(const ::VlUnpacked<::QData/*63:0*/, 1> &triggers, const ::std::string &tag);
#endif  // VL_DEBUG
void Vguitar_top___024root___trigger_orInto__act_vec_vec(::VlUnpacked<::QData/*63:0*/, 1> &out, const ::VlUnpacked<::QData/*63:0*/, 1> &in);

bool Vguitar_top___024root___eval_act(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_act\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    {
        // Inlined CFunc: _eval_triggers_vec__act
        vlSelfRef.__VactTriggered[0U] = (::QData)((::IData)(
                                                            ((::IData)(vlSelfRef.__VprimaryPorts.clk50) 
                                                             & (~ (::IData)(vlSelfRef.__Vtrigprevexpr___TOP__clk50__1)))));
        vlSelfRef.__Vtrigprevexpr___TOP__clk50__1 = vlSelfRef.__VprimaryPorts.clk50;
    }
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vguitar_top___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
    }
#endif
    Vguitar_top___024root___trigger_orInto__act_vec_vec(vlSelfRef.__VnbaTriggered, vlSelfRef.__VactTriggered);
    return (0U);
}

bool Vguitar_top___024root___eval_inact(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_inact\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    return (0U);
}

bool Vguitar_top___024root___trigger_anySet__act(const ::VlUnpacked<::QData/*63:0*/, 1> &in);
void Vguitar_top___024root___nba_sequent__TOP__0(Vguitar_top___024root* vlSelf);
void Vguitar_top___024root___trigger_clear__act(::VlUnpacked<::QData/*63:0*/, 1> &out);

bool Vguitar_top___024root___eval_nba(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_nba\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    ::CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = Vguitar_top___024root___trigger_anySet__act(vlSelfRef.__VnbaTriggered);
    if (__VnbaExecute) {
        {
            // Inlined CFunc: _eval_body__nba
            if ((((1ULL & vlSelfRef.__VnbaTriggered[0U])) != 0ULL)) {
                Vguitar_top___024root___nba_sequent__TOP__0(vlSelf);
            }
        }
        Vguitar_top___024root___trigger_clear__act(vlSelfRef.__VnbaTriggered);
    }
    return (__VnbaExecute);
}

bool Vguitar_top___024root___eval_obs(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_obs\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    return (0U);
}

bool Vguitar_top___024root___eval_react(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_react\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    return (0U);
}

void Vguitar_top___024root___eval_postponed(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_postponed\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

bool Vguitar_top___024root___trigger_anySet__ico(const ::VlUnpacked<::QData/*63:0*/, 2> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___trigger_anySet__ico\n"); );
    // Locals
    ::IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((::IData)(1U) + n);
    } while ((2U > n));
    return (0U);
}

bool Vguitar_top___024root___trigger_anySet__act(const ::VlUnpacked<::QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___trigger_anySet__act\n"); );
    // Locals
    ::IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((::IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

extern const ::VlWide<40>/*1279:0*/ Vguitar_top__ConstPool__CONST_0;

void Vguitar_top___024root___nba_sequent__TOP__0(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___nba_sequent__TOP__0\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    ::CData/*0:0*/ __Vdfg_Regularize_1113;
    __Vdfg_Regularize_1113 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1117;
    __Vdfg_Regularize_1117 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1118;
    __Vdfg_Regularize_1118 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1119;
    __Vdfg_Regularize_1119 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1120;
    __Vdfg_Regularize_1120 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1121;
    __Vdfg_Regularize_1121 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1122;
    __Vdfg_Regularize_1122 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1123;
    __Vdfg_Regularize_1123 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1124;
    __Vdfg_Regularize_1124 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1125;
    __Vdfg_Regularize_1125 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1127;
    __Vdfg_Regularize_1127 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1128;
    __Vdfg_Regularize_1128 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1130;
    __Vdfg_Regularize_1130 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1131;
    __Vdfg_Regularize_1131 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1132;
    __Vdfg_Regularize_1132 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1133;
    __Vdfg_Regularize_1133 = 0;
    ::CData/*1:0*/ __Vdfg_Regularize_1140;
    __Vdfg_Regularize_1140 = 0;
    ::SData/*10:0*/ __Vdfg_Regularize_1141;
    __Vdfg_Regularize_1141 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1142;
    __Vdfg_Regularize_1142 = 0;
    ::CData/*2:0*/ __Vdly__guitar_top__DOT__feeder__DOT__state_0;
    __Vdly__guitar_top__DOT__feeder__DOT__state_0 = 0;
    ::CData/*3:0*/ __Vdly__guitar_top__DOT__feeder__DOT__hdr_idx_1;
    __Vdly__guitar_top__DOT__feeder__DOT__hdr_idx_1 = 0;
    ::CData/*2:0*/ __Vdly__guitar_top__DOT__feeder__DOT__lane_2;
    __Vdly__guitar_top__DOT__feeder__DOT__lane_2 = 0;
    ::SData/*14:0*/ __Vdly__guitar_top__DOT__feeder__DOT__frame_count_4;
    __Vdly__guitar_top__DOT__feeder__DOT__frame_count_4 = 0;
    ::VlWide<40>/*1279:0*/ __Vdly__guitar_top__DOT__feeder__DOT__slots_5;
    VL_ZERO_W(1280, __Vdly__guitar_top__DOT__feeder__DOT__slots_5);
    ::CData/*4:0*/ __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6;
    __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6 = 0;
    ::IData/*19:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9 = 0;
    ::IData/*19:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10 = 0;
    ::IData/*19:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11 = 0;
    ::IData/*19:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12 = 0;
    ::IData/*19:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13 = 0;
    ::IData/*19:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14 = 0;
    ::CData/*0:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en_15;
    __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en_15 = 0;
    ::SData/*9:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt_16;
    __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt_16 = 0;
    ::SData/*9:0*/ __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt_17;
    __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt_17 = 0;
    ::CData/*1:0*/ __Vdly__guitar_top__DOT__hit_unit__DOT__state_19;
    __Vdly__guitar_top__DOT__hit_unit__DOT__state_19 = 0;
    ::SData/*15:0*/ __Vdly__score_20;
    __Vdly__score_20 = 0;
    ::CData/*0:0*/ __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21;
    __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21 = 0;
    ::CData/*0:0*/ __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_22;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_22 = 0;
    ::SData/*15:0*/ __Vdly_Val__guitar_top__DOT__feeder__DOT__note_count_23;
    __Vdly_Val__guitar_top__DOT__feeder__DOT__note_count_23 = 0;
    ::CData/*2:0*/ __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_count_24;
    __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_count_24 = 0;
    ::CData/*0:0*/ __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_25;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_25 = 0;
    ::CData/*0:0*/ __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_26;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_26 = 0;
    ::SData/*15:0*/ __Vdly_Val__guitar_top__DOT__feeder__DOT__note_start_27;
    __Vdly_Val__guitar_top__DOT__feeder__DOT__note_start_27 = 0;
    ::CData/*2:0*/ __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_start_28;
    __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_start_28 = 0;
    ::CData/*0:0*/ __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_29;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_29 = 0;
    ::CData/*0:0*/ __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_30;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_30 = 0;
    ::SData/*15:0*/ __Vdly_Val__guitar_top__DOT__feeder__DOT__note_ptr_31;
    __Vdly_Val__guitar_top__DOT__feeder__DOT__note_ptr_31 = 0;
    ::CData/*2:0*/ __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_ptr_32;
    __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_ptr_32 = 0;
    ::CData/*0:0*/ __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_33;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_33 = 0;
    ::IData/*31:0*/ __Vilp1;
    ::IData/*31:0*/ __Vilp2;
    ::IData/*31:0*/ __Vilp3;
    // Body
    __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en_15 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en;
    __Vdly__guitar_top__DOT__feeder__DOT__hdr_idx_1 
        = vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx;
    __Vdly__guitar_top__DOT__hit_unit__DOT__state_19 
        = vlSelfRef.guitar_top__DOT__hit_unit__DOT__state;
    __Vdly__guitar_top__DOT__feeder__DOT__frame_count_4 
        = vlSelfRef.guitar_top__DOT__feeder__DOT__frame_count;
    __Vdly__guitar_top__DOT__feeder__DOT__state_0 = vlSelfRef.guitar_top__DOT__feeder__DOT__state;
    __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21 
        = vlSelfRef.guitar_top__DOT__hit_unit__DOT__strum_pending;
    __Vdly__score_20 = vlSelfRef.__VprimaryPorts.score;
    __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6 
        = vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_22 = 0U;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_25 = 0U;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_26 = 0U;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_29 = 0U;
    __Vdly__guitar_top__DOT__feeder__DOT__lane_2 = vlSelfRef.guitar_top__DOT__feeder__DOT__lane;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_30 = 0U;
    __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_33 = 0U;
    __Vilp1 = 0U;
    while ((__Vilp1 <= 0x00000027U)) {
        __Vdly__guitar_top__DOT__feeder__DOT__slots_5[__Vilp1] 
            = vlSelfRef.guitar_top__DOT__feeder__DOT__slots
            [__Vilp1];
        __Vilp1 = ((::IData)(1U) + __Vilp1);
    }
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__;
    __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__;
    __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt_17 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt;
    __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt_16 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt;
    __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en_15 
        = (1U & ((~ (::IData)(vlSelfRef.__VprimaryPorts.rst)) 
                 & (~ (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en))));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__last_x 
        = vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt;
    if (vlSelfRef.__VprimaryPorts.rst) {
        __Vdly__guitar_top__DOT__feeder__DOT__hdr_idx_1 = 0U;
        __Vdly__guitar_top__DOT__hit_unit__DOT__state_19 = 0U;
        __Vdly__guitar_top__DOT__feeder__DOT__frame_count_4 = 0U;
        __Vdly__guitar_top__DOT__feeder__DOT__state_0 = 0U;
        __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21 = 0U;
        __Vdly__score_20 = 0U;
        vlSelfRef.__VprimaryPorts.score = __Vdly__score_20;
        vlSelfRef.guitar_top__DOT__hit_unit__DOT__state 
            = __Vdly__guitar_top__DOT__hit_unit__DOT__state_19;
        vlSelfRef.guitar_top__DOT__hit_unit__DOT__strum_pending 
            = __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21;
        __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6 = 0U;
        __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_22 = 1U;
        __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_26 = 1U;
        __Vdly__guitar_top__DOT__feeder__DOT__lane_2 = 0U;
        __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_30 = 1U;
        VL_ASSIGN_W(1280, __Vdly__guitar_top__DOT__feeder__DOT__slots_5, Vguitar_top__ConstPool__CONST_0);
        vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold 
            = __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6;
        vlSelfRef.guitar_top__DOT__feeder__DOT__frame_count 
            = __Vdly__guitar_top__DOT__feeder__DOT__frame_count_4;
        __Vilp2 = 0U;
        while ((__Vilp2 <= 0x00000027U)) {
            vlSelfRef.guitar_top__DOT__feeder__DOT__slots[__Vilp2] 
                = __Vdly__guitar_top__DOT__feeder__DOT__slots_5
                [__Vilp2];
            __Vilp2 = ((::IData)(1U) + __Vilp2);
        }
        __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14 = 0U;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14;
        __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9 = 0U;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9;
        __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10 = 0U;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10;
        __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11 = 0U;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11;
        __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12 = 0U;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12;
        __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13 = 0U;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13;
        __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt_17 = 0U;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt_17;
        __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt_16 = 0U;
    } else {
        if ((1U & (~ ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state) 
                      >> 2U)))) {
            if ((2U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
                if ((1U & (~ (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state)))) {
                    if ((9U != (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx))) {
                        __Vdly__guitar_top__DOT__feeder__DOT__hdr_idx_1 
                            = (0x0000000fU & ((::IData)(1U) 
                                              + (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx)));
                    }
                    if ((5U > (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx))) {
                        if ((4U >= (7U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx)))) {
                            __Vdly_Val__guitar_top__DOT__feeder__DOT__note_count_23 
                                = vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__dout;
                            __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_count_24 
                                = (7U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx));
                            __Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_25 = 1U;
                        }
                    }
                    if ((5U <= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx))) {
                        if ((4U >= (7U & ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx) 
                                          - (::IData)(5U))))) {
                            __Vdly_Val__guitar_top__DOT__feeder__DOT__note_start_27 
                                = vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__dout;
                            __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_start_28 
                                = (7U & ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx) 
                                         - (::IData)(5U)));
                            __Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_29 = 1U;
                        }
                    }
                }
                if ((1U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
                    if (vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__frame_tick) {
                        __Vdly__guitar_top__DOT__feeder__DOT__frame_count_4 
                            = (0x00007fffU & ((::IData)(1U) 
                                              + (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__frame_count)));
                    }
                }
            }
        }
        if ((4U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
            if ((2U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
                __Vdly__guitar_top__DOT__feeder__DOT__state_0 
                    = ((1U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))
                        ? 3U : 4U);
                if ((1U & (~ (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state)))) {
                    if (((0x00007fffU & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__dout)) 
                         <= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__frame_count))) {
                        if ((0x00008000U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__dout))) {
                            if ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))) {
                                __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6 
                                    = ((::IData)(__Vdly__guitar_top__DOT__feeder__DOT__in_hold_6) 
                                       | (0x1fU & ((::IData)(1U) 
                                                   << (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))));
                            }
                            if ((0x04ffU >= (0x000007ffU 
                                             & ((::IData)(0x00feU) 
                                                + ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane) 
                                                   << 8U))))) {
                                VL_ASSIGNSEL_WI(1280, 2, 
                                                (0x000007ffU 
                                                 & ((::IData)(0x00feU) 
                                                    + 
                                                    ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane) 
                                                     << 8U))), __Vdly__guitar_top__DOT__feeder__DOT__slots_5, 1U);
                            }
                        } else if (((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane)) 
                                    && (1U & ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold) 
                                              >> (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))))) {
                            if ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))) {
                                __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6 
                                    = ((~ ((::IData)(1U) 
                                           << (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))) 
                                       & (::IData)(__Vdly__guitar_top__DOT__feeder__DOT__in_hold_6));
                            }
                            if ((0x04ffU >= (0x000007ffU 
                                             & ((::IData)(0x00feU) 
                                                + ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane) 
                                                   << 8U))))) {
                                VL_ASSIGNSEL_WI(1280, 2, 
                                                (0x000007ffU 
                                                 & ((::IData)(0x00feU) 
                                                    + 
                                                    ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane) 
                                                     << 8U))), __Vdly__guitar_top__DOT__feeder__DOT__slots_5, 3U);
                            }
                        } else if ((0x04ffU >= (0x000007ffU 
                                                & ((::IData)(0x00feU) 
                                                   + 
                                                   ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane) 
                                                    << 8U))))) {
                            VL_ASSIGNSEL_WI(1280, 2, 
                                            (0x000007ffU 
                                             & ((::IData)(0x00feU) 
                                                + ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane) 
                                                   << 8U))), __Vdly__guitar_top__DOT__feeder__DOT__slots_5, 1U);
                        }
                        if ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))) {
                            __Vdly_Val__guitar_top__DOT__feeder__DOT__note_ptr_31 
                                = (0x0000ffffU & ((::IData)(1U) 
                                                  + 
                                                  ((4U 
                                                    >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                                                    ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr
                                                   [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                                                    : 0U)));
                            __Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_ptr_32 
                                = vlSelfRef.guitar_top__DOT__feeder__DOT__lane;
                            __Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_33 = 1U;
                        }
                    }
                    if (((0x00007fffU & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__dout)) 
                         > (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__frame_count))) {
                        __Vdly__guitar_top__DOT__feeder__DOT__lane_2 
                            = (7U & ((::IData)(1U) 
                                     + (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane)));
                    }
                }
            } else {
                if ((1U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
                    __Vdly__guitar_top__DOT__feeder__DOT__state_0 = 6U;
                } else if ((5U == (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))) {
                    __Vdly__guitar_top__DOT__feeder__DOT__state_0 = 3U;
                } else if ((((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                              ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr
                             [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                              : 0U) < ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                                        ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_count
                                       [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                                        : 0U))) {
                    __Vdly__guitar_top__DOT__feeder__DOT__state_0 = 5U;
                }
                if ((1U & (~ (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state)))) {
                    if ((5U != (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))) {
                        if ((((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                               ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr
                              [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                               : 0U) >= ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                                          ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_count
                                         [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                                          : 0U))) {
                            __Vdly__guitar_top__DOT__feeder__DOT__lane_2 
                                = (7U & ((::IData)(1U) 
                                         + (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane)));
                        }
                    }
                }
            }
        } else if ((2U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
            if ((1U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
                if (vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__frame_tick) {
                    __Vdly__guitar_top__DOT__feeder__DOT__state_0 = 4U;
                    __Vdly__guitar_top__DOT__feeder__DOT__lane_2 = 0U;
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[0U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[1U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[1U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[2U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[1U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[2U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[3U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[2U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[3U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[4U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[3U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[4U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[5U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[4U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[5U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[6U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[5U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[6U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[7U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[6U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[7U] 
                        = ((((1U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold))
                              ? 2U : 0U) << 0x0000001eU) 
                           | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[7U] 
                              >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[8U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[9U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[9U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[10U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[9U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[10U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[11U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[10U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[11U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[12U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[11U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[12U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[13U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[12U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[13U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[14U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[13U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[14U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[15U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[14U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[15U] 
                        = ((((2U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold))
                              ? 2U : 0U) << 0x0000001eU) 
                           | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[15U] 
                              >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[16U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[17U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[17U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[18U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[17U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[18U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[19U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[18U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[19U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[20U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[19U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[20U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[21U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[20U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[21U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[22U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[21U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[22U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[23U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[22U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[23U] 
                        = ((((4U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold))
                              ? 2U : 0U) << 0x0000001eU) 
                           | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[23U] 
                              >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[24U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[25U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[25U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[26U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[25U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[26U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[27U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[26U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[27U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[28U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[27U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[28U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[29U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[28U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[29U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[30U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[29U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[30U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[31U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[30U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[31U] 
                        = ((((8U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold))
                              ? 2U : 0U) << 0x0000001eU) 
                           | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[31U] 
                              >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[32U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[33U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[33U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[34U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[33U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[34U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[35U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[34U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[35U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[36U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[35U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[36U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[37U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[36U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[37U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[38U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[37U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[38U] 
                        = ((vlSelfRef.guitar_top__DOT__feeder__DOT__slots[39U] 
                            << 0x0000001eU) | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[38U] 
                                               >> 2U));
                    __Vdly__guitar_top__DOT__feeder__DOT__slots_5[39U] 
                        = ((((0x00000010U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold))
                              ? 2U : 0U) << 0x0000001eU) 
                           | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[39U] 
                              >> 2U));
                }
            } else {
                __Vdly__guitar_top__DOT__feeder__DOT__state_0 
                    = ((9U == (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx))
                        ? 3U : 0U);
            }
        } else {
            __Vdly__guitar_top__DOT__feeder__DOT__state_0 
                = ((1U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))
                    ? 2U : 1U);
        }
        if (((~ (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__strum_prev)) 
             & (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__raw_strum))) {
            __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21 = 1U;
        }
        if (vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__frame_tick) {
            if ((0U == (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__state))) {
                if (vlSelfRef.guitar_top__DOT__hit_unit__DOT__strum_pending) {
                    if (vlSelfRef.guitar_top__DOT__hit_unit__DOT__fret_match) {
                        __Vdly__guitar_top__DOT__hit_unit__DOT__state_19 = 1U;
                        __Vdly__score_20 = (0x0000ffffU 
                                            & ((::IData)(0x000aU) 
                                               + (::IData)(vlSelfRef.__VprimaryPorts.score)));
                    } else {
                        __Vdly__score_20 = (0x0000ffffU 
                                            & ((::IData)(vlSelfRef.__VprimaryPorts.score) 
                                               - (::IData)(0x000aU)));
                    }
                    __Vdly__guitar_top__DOT__hit_unit__DOT__state_19 = 1U;
                    __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21 = 0U;
                } else if (((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U])) 
                            | ((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U])) 
                               | ((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U])) 
                                  | ((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U])) 
                                     | (1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U]))))))) {
                    __Vdly__score_20 = (0x0000ffffU 
                                        & ((::IData)(vlSelfRef.__VprimaryPorts.score) 
                                           - (::IData)(0x0032U)));
                }
            } else {
                __Vdly__guitar_top__DOT__hit_unit__DOT__state_19 = 0U;
                if ((1U == (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__state))) {
                    __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21 = 0U;
                }
            }
        }
        vlSelfRef.__VprimaryPorts.score = __Vdly__score_20;
        vlSelfRef.guitar_top__DOT__hit_unit__DOT__state 
            = __Vdly__guitar_top__DOT__hit_unit__DOT__state_19;
        vlSelfRef.guitar_top__DOT__hit_unit__DOT__strum_pending 
            = __Vdly__guitar_top__DOT__hit_unit__DOT__strum_pending_21;
        vlSelfRef.guitar_top__DOT__feeder__DOT__in_hold 
            = __Vdly__guitar_top__DOT__feeder__DOT__in_hold_6;
        vlSelfRef.guitar_top__DOT__feeder__DOT__frame_count 
            = __Vdly__guitar_top__DOT__feeder__DOT__frame_count_4;
        __Vilp3 = 0U;
        while ((__Vilp3 <= 0x00000027U)) {
            vlSelfRef.guitar_top__DOT__feeder__DOT__slots[__Vilp3] 
                = __Vdly__guitar_top__DOT__feeder__DOT__slots_5
                [__Vilp3];
            __Vilp3 = ((::IData)(1U) + __Vilp3);
        }
        if (vlSelfRef.guitar_top__DOT__draw_unit__DOT__new_line) {
            if ((0x0040U == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))) {
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14 = 0x00017000U;
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9 = 0x00011000U;
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10 = 0x00012300U;
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11 = 0x00013600U;
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12 = 0x00014900U;
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13 = 0x00015c00U;
            } else if (((0x0040U < (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                        & (0x01c0U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)))) {
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14 
                    = (0x000fffffU & ((::IData)(0x000000a0U) 
                                      + vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__));
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9 
                    = (0x000fffffU & ((::IData)(0x000fff60U) 
                                      + vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__));
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10 
                    = (0x000fffffU & ((::IData)(0x000fffa0U) 
                                      + vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__));
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11 
                    = (0x000fffffU & ((::IData)(0x000fffe0U) 
                                      + vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__));
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12 
                    = (0x000fffffU & ((::IData)(0x00000020U) 
                                      + vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__));
                __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13 
                    = (0x000fffffU & ((::IData)(0x00000060U) 
                                      + vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__));
            }
        }
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET___14;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET___9;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET___10;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET___11;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET___12;
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET___13;
        if (vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en) {
            if ((0x031fU == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt))) {
                __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt_17 
                    = ((0x020cU == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))
                        ? 0U : (0x000003ffU & ((::IData)(1U) 
                                               + (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))));
                __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt_16 = 0U;
            } else {
                __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt_16 
                    = (0x000003ffU & ((::IData)(1U) 
                                      + (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)));
            }
        }
        vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt 
            = __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt_17;
    }
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en 
        = __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en_15;
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt 
        = __Vdly__guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt_16;
    vlSelfRef.guitar_top__DOT__hit_unit__DOT__strum_prev 
        = ((1U & (~ (::IData)(vlSelfRef.__VprimaryPorts.rst))) 
           && (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__raw_strum));
    vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone 
        = (((((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U])) 
              | ((1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U] 
                               >> 6U))) | ((1U == (3U 
                                                   & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U] 
                                                      >> 4U))) 
                                           | (1U == 
                                              (3U & 
                                               (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U] 
                                                >> 2U)))))) 
             << 4U) | ((((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U])) 
                         | ((1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U] 
                                          >> 6U))) 
                            | ((1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U] 
                                             >> 4U))) 
                               | (1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U] 
                                               >> 2U)))))) 
                        << 3U) | (((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U])) 
                                   | ((1U == (3U & 
                                              (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U] 
                                               >> 6U))) 
                                      | ((1U == (3U 
                                                 & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U] 
                                                    >> 4U))) 
                                         | (1U == (3U 
                                                   & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U] 
                                                      >> 2U)))))) 
                                  << 2U))) | ((((1U 
                                                 == 
                                                 (3U 
                                                  & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U])) 
                                                | ((1U 
                                                    == 
                                                    (3U 
                                                     & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U] 
                                                        >> 6U))) 
                                                   | ((1U 
                                                       == 
                                                       (3U 
                                                        & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U] 
                                                           >> 4U))) 
                                                      | (1U 
                                                         == 
                                                         (3U 
                                                          & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U] 
                                                             >> 2U)))))) 
                                               << 1U) 
                                              | ((1U 
                                                  == 
                                                  (3U 
                                                   & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U] 
                                                      >> 6U))) 
                                                 | ((1U 
                                                     == 
                                                     (3U 
                                                      & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U] 
                                                         >> 4U))) 
                                                    | ((1U 
                                                        == 
                                                        (3U 
                                                         & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U] 
                                                            >> 2U))) 
                                                       | (1U 
                                                          == 
                                                          (3U 
                                                           & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U])))))));
    vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__dout 
        = vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__mem
        [vlSelfRef.guitar_top__DOT__feeder__DOT__addr];
    if (vlSelfRef.__VprimaryPorts.rst) {
        vlSelfRef.guitar_top__DOT__feeder__DOT__addr = 0U;
    } else if ((4U & (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state))) {
        if ((1U & (~ ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state) 
                      >> 1U)))) {
            if ((1U & (~ (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state)))) {
                if ((5U != (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))) {
                    if ((((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                           ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr
                          [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                           : 0U) < ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                                     ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_count
                                    [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                                     : 0U))) {
                        vlSelfRef.guitar_top__DOT__feeder__DOT__addr 
                            = (0x000007ffU & (((4U 
                                                >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                                                ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_start
                                               [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                                                : 0U) 
                                              + ((4U 
                                                  >= (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__lane))
                                                  ? vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr
                                                 [vlSelfRef.guitar_top__DOT__feeder__DOT__lane]
                                                  : 0U)));
                    }
                }
            }
        }
    } else if ((1U & (~ ((::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state) 
                         >> 1U)))) {
        if ((1U & (~ (::IData)(vlSelfRef.guitar_top__DOT__feeder__DOT__state)))) {
            vlSelfRef.guitar_top__DOT__feeder__DOT__addr 
                = vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx;
        }
    }
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[5U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[0U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[1U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[2U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[3U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[4U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                          >> 8U));
    vlSelfRef.__VprimaryPorts.vsync = (1U & (~ ((0x01eaU 
                                                 <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                                & (0x01ecU 
                                                   > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)))));
    __Vdfg_Regularize_1142 = (((0x01e0U > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                               & (0x01dfU >= (0x000001ffU 
                                              & (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))))
                               ? vlSymsp->vlInst.TOP__highway_pkg.SLOT_LUT
                              [(0x000001ffU & (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))]
                               : 0U);
    __Vdfg_Regularize_1113 = ((0x0040U <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                              & (0x01c0U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)));
    vlSelfRef.__VprimaryPorts.vga_clk = vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en;
    vlSelfRef.__VprimaryPorts.hsync = (1U & (~ ((0x0290U 
                                                 <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)) 
                                                & (0x02f0U 
                                                   > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)))));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__new_line 
        = ((0U == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)) 
           & (0U != (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__last_x)));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__frame_tick 
        = ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en) 
           & ((0U == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)) 
              & (0x01e0U == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))));
    vlSelfRef.__VprimaryPorts.blank_n = ((0x01e0U > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                         & (0x0280U 
                                            > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)));
    __Vdfg_Regularize_1121 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1122 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1123 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1124 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1119 = ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                              >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
                                                 >> 8U)));
    vlSelfRef.guitar_top__DOT__hit_unit__DOT__fret_match 
        = (((::IData)(vlSelfRef.__VprimaryPorts.fret) 
            == (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone)) 
           & (0U != (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone)));
    vlSelfRef.__Vdfg_Regularize_1115 = (0x000000ffU 
                                        & (- (::IData)(
                                                       (((::IData)(__Vdfg_Regularize_1119) 
                                                         & (((0x0040U 
                                                              == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                                             | (0x01c0U 
                                                                == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))) 
                                                            & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                               <= 
                                                               (0x000003ffU 
                                                                & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                                                                   >> 8U))))) 
                                                        | ((((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                             == 
                                                             (0x000003ffU 
                                                              & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                                                                 >> 8U))) 
                                                            | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                == 
                                                                (0x000003ffU 
                                                                 & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                                                                    >> 8U))) 
                                                               | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                   == 
                                                                   (0x000003ffU 
                                                                    & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                                                                       >> 8U))) 
                                                                  | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                      == 
                                                                      (0x000003ffU 
                                                                       & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                                                                          >> 8U))) 
                                                                     | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                         == 
                                                                         (0x000003ffU 
                                                                          & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
                                                                             >> 8U))) 
                                                                        | ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                           == 
                                                                           (0x000003ffU 
                                                                            & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                                                                               >> 8U)))))))) 
                                                           & (::IData)(__Vdfg_Regularize_1113))))));
    __Vdfg_Regularize_1120 = ((::IData)(__Vdfg_Regularize_1119) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                                                   >> 8U))));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__in_highway 
        = (((::IData)(__Vdfg_Regularize_1120) | ((::IData)(__Vdfg_Regularize_1121) 
                                                 | ((::IData)(__Vdfg_Regularize_1122) 
                                                    | ((::IData)(__Vdfg_Regularize_1123) 
                                                       | (::IData)(__Vdfg_Regularize_1124))))) 
           & (::IData)(__Vdfg_Regularize_1113));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx 
        = ((- (::IData)((1U & (~ (::IData)(__Vdfg_Regularize_1120))))) 
           & (((::IData)(__Vdfg_Regularize_1121) ? 1U
                : ((::IData)(__Vdfg_Regularize_1122)
                    ? 2U : ((::IData)(__Vdfg_Regularize_1123)
                             ? 3U : (4U & (- (::IData)((::IData)(__Vdfg_Regularize_1124))))))) 
              & (- (::IData)((::IData)(__Vdfg_Regularize_1113)))));
    if (__Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_26) {
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_start[0U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_start[1U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_start[2U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_start[3U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_start[4U] = 0U;
    }
    if (__Vdly_Set__guitar_top__DOT__feeder__DOT__note_start_29) {
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_start[__Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_start_28] 
            = __Vdly_Val__guitar_top__DOT__feeder__DOT__note_start_27;
    }
    vlSelfRef.guitar_top__DOT__feeder__DOT__hdr_idx 
        = __Vdly__guitar_top__DOT__feeder__DOT__hdr_idx_1;
    vlSelfRef.guitar_top__DOT__feeder__DOT__lane = __Vdly__guitar_top__DOT__feeder__DOT__lane_2;
    if (__Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_22) {
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_count[0U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_count[1U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_count[2U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_count[3U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_count[4U] = 0U;
    }
    if (__Vdly_Set__guitar_top__DOT__feeder__DOT__note_count_25) {
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_count[__Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_count_24] 
            = __Vdly_Val__guitar_top__DOT__feeder__DOT__note_count_23;
    }
    if (__Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_30) {
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr[0U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr[1U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr[2U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr[3U] = 0U;
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr[4U] = 0U;
    }
    if (__Vdly_Set__guitar_top__DOT__feeder__DOT__note_ptr_33) {
        vlSelfRef.guitar_top__DOT__feeder__DOT__note_ptr[__Vdly_Dim0__guitar_top__DOT__feeder__DOT__note_ptr_32] 
            = __Vdly_Val__guitar_top__DOT__feeder__DOT__note_ptr_31;
    }
    vlSelfRef.guitar_top__DOT__feeder__DOT__state = __Vdly__guitar_top__DOT__feeder__DOT__state_0;
    __Vdfg_Regularize_1117 = ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__in_highway) 
                              & ((0x01c0U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                 & (((4U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)) 
                                     && (1U & ((::IData)(vlSelfRef.__VprimaryPorts.fret) 
                                               >> (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)))) 
                                    & (0x0180U <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)))));
    if ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx))) {
        __Vdfg_Regularize_1131 = vlSymsp->vlInst.TOP__highway_pkg.LANE_R
            [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx];
        __Vdfg_Regularize_1132 = vlSymsp->vlInst.TOP__highway_pkg.LANE_G
            [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx];
        __Vdfg_Regularize_1133 = vlSymsp->vlInst.TOP__highway_pkg.LANE_B
            [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx];
    } else {
        __Vdfg_Regularize_1131 = 0U;
        __Vdfg_Regularize_1132 = 0U;
        __Vdfg_Regularize_1133 = 0U;
    }
    __Vdfg_Regularize_1141 = (0x000007ffU & ((0x000000ffU 
                                              & ((::IData)(__Vdfg_Regularize_1142) 
                                                 << 1U)) 
                                             + ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx) 
                                                << 8U)));
    __Vdfg_Regularize_1125 = ((5U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx))
                               ? vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x
                              [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx]
                               : 0U);
    __Vdfg_Regularize_1140 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__in_highway) 
                               & ((0x04ffU >= (::IData)(__Vdfg_Regularize_1141)) 
                                  & ((::IData)(__Vdfg_Regularize_1142) 
                                     >> 7U))) ? (3U 
                                                 & (((0U 
                                                      == 
                                                      (0x0000001fU 
                                                       & (::IData)(__Vdfg_Regularize_1141)))
                                                      ? 0U
                                                      : 
                                                     (vlSelfRef.guitar_top__DOT__feeder__DOT__slots
                                                      [
                                                      (((::IData)(1U) 
                                                        + (::IData)(__Vdfg_Regularize_1141)) 
                                                       >> 5U)] 
                                                      << 
                                                      ((::IData)(0x00000020U) 
                                                       - 
                                                       (0x0000001fU 
                                                        & (::IData)(__Vdfg_Regularize_1141))))) 
                                                    | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots
                                                       [
                                                       ((::IData)(__Vdfg_Regularize_1141) 
                                                        >> 5U)] 
                                                       >> 
                                                       (0x0000001fU 
                                                        & (::IData)(__Vdfg_Regularize_1141)))))
                               : 0U);
    __Vdfg_Regularize_1127 = (0x000003ffU & (((5U >= 
                                               (7U 
                                                & ((::IData)(1U) 
                                                   + (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx))))
                                               ? vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x
                                              [(7U 
                                                & ((::IData)(1U) 
                                                   + (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)))]
                                               : 0U) 
                                             - (::IData)(__Vdfg_Regularize_1125)));
    __Vdfg_Regularize_1130 = ((0U == ((::IData)(__Vdfg_Regularize_1127) 
                                      >> 3U)) ? 1U : 
                              ((::IData)(__Vdfg_Regularize_1127) 
                               >> 3U));
    __Vdfg_Regularize_1128 = (0x000003ffU & ((::IData)(__Vdfg_Regularize_1125) 
                                             + ((::IData)(__Vdfg_Regularize_1127) 
                                                >> 1U)));
    __Vdfg_Regularize_1118 = (0x000000ffU & (- (::IData)(
                                                         ((2U 
                                                           == (::IData)(__Vdfg_Regularize_1140)) 
                                                          & (((0x000003ffU 
                                                               & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                  + (::IData)(__Vdfg_Regularize_1130))) 
                                                              >= (::IData)(__Vdfg_Regularize_1128)) 
                                                             & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                <= 
                                                                (0x000003ffU 
                                                                 & ((::IData)(__Vdfg_Regularize_1130) 
                                                                    + (::IData)(__Vdfg_Regularize_1128)))))))));
    if ((1U == (::IData)(__Vdfg_Regularize_1140))) {
        vlSelfRef.__Vdfg_Regularize_1134 = __Vdfg_Regularize_1131;
        vlSelfRef.__Vdfg_Regularize_1135 = __Vdfg_Regularize_1132;
        vlSelfRef.__Vdfg_Regularize_1136 = __Vdfg_Regularize_1133;
    } else {
        vlSelfRef.__Vdfg_Regularize_1134 = (((::IData)(__Vdfg_Regularize_1131) 
                                             >> 1U) 
                                            & (::IData)(__Vdfg_Regularize_1118));
        vlSelfRef.__Vdfg_Regularize_1135 = (((::IData)(__Vdfg_Regularize_1132) 
                                             >> 1U) 
                                            & (::IData)(__Vdfg_Regularize_1118));
        vlSelfRef.__Vdfg_Regularize_1136 = (((::IData)(__Vdfg_Regularize_1133) 
                                             >> 1U) 
                                            & (::IData)(__Vdfg_Regularize_1118));
    }
    vlSelfRef.__Vdfg_Regularize_1139 = (0x000001ffU 
                                        & ((0x000001fcU 
                                            & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt) 
                                               << 2U)) 
                                           + (::IData)(vlSelfRef.__Vdfg_Regularize_1134)));
    vlSelfRef.__Vdfg_Regularize_1137 = (0x000001ffU 
                                        & ((::IData)(vlSelfRef.__Vdfg_Regularize_1135) 
                                           + (0x000001fcU 
                                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt) 
                                                 << 2U))));
    vlSelfRef.__Vdfg_Regularize_1138 = (0x000001ffU 
                                        & ((::IData)(vlSelfRef.__Vdfg_Regularize_1136) 
                                           + (0x000001fcU 
                                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt) 
                                                 << 2U))));
    vlSelfRef.__VprimaryPorts.r = (0x000000ffU & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                  & (((::IData)(__Vdfg_Regularize_1117)
                                                       ? 
                                                      ((::IData)(vlSelfRef.__Vdfg_Regularize_1139) 
                                                       | (- (::IData)(
                                                                      (1U 
                                                                       & ((::IData)(vlSelfRef.__Vdfg_Regularize_1139) 
                                                                          >> 8U)))))
                                                       : (::IData)(vlSelfRef.__Vdfg_Regularize_1134)) 
                                                     | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
    vlSelfRef.__VprimaryPorts.g = (0x000000ffU & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                  & (((::IData)(__Vdfg_Regularize_1117)
                                                       ? 
                                                      ((::IData)(vlSelfRef.__Vdfg_Regularize_1137) 
                                                       | (- (::IData)(
                                                                      (1U 
                                                                       & ((::IData)(vlSelfRef.__Vdfg_Regularize_1137) 
                                                                          >> 8U)))))
                                                       : (::IData)(vlSelfRef.__Vdfg_Regularize_1135)) 
                                                     | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
    vlSelfRef.__VprimaryPorts.b = (0x000000ffU & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                  & (((::IData)(__Vdfg_Regularize_1117)
                                                       ? 
                                                      ((::IData)(vlSelfRef.__Vdfg_Regularize_1138) 
                                                       | (- (::IData)(
                                                                      (1U 
                                                                       & ((::IData)(vlSelfRef.__Vdfg_Regularize_1138) 
                                                                          >> 8U)))))
                                                       : (::IData)(vlSelfRef.__Vdfg_Regularize_1136)) 
                                                     | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
}

void Vguitar_top___024root___trigger_orInto__act_vec_vec(::VlUnpacked<::QData/*63:0*/, 1> &out, const ::VlUnpacked<::QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___trigger_orInto__act_vec_vec\n"); );
    // Locals
    ::IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = (out[n] | in[n]);
        n = ((::IData)(1U) + n);
    } while ((0U >= n));
}

void Vguitar_top___024root___trigger_clear__act(::VlUnpacked<::QData/*63:0*/, 1> &out) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___trigger_clear__act\n"); );
    // Locals
    ::IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        out[n] = 0ULL;
        n = ((::IData)(1U) + n);
    } while ((1U > n));
}

#ifdef VL_DEBUG
void Vguitar_top___024root___eval_debug_assertions(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_debug_assertions\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if (VL_UNLIKELY(((vlSelfRef.__VprimaryPorts.clk50 
                      & 0xfeU)))) {
        Verilated::overWidthError("clk50");
    }
    if (VL_UNLIKELY(((vlSelfRef.__VprimaryPorts.rst 
                      & 0xfeU)))) {
        Verilated::overWidthError("rst");
    }
    if (VL_UNLIKELY(((vlSelfRef.__VprimaryPorts.fret 
                      & 0xe0U)))) {
        Verilated::overWidthError("fret");
    }
    if (VL_UNLIKELY(((vlSelfRef.__VprimaryPorts.strum_up 
                      & 0xfeU)))) {
        Verilated::overWidthError("strum_up");
    }
    if (VL_UNLIKELY(((vlSelfRef.__VprimaryPorts.strum_down 
                      & 0xfeU)))) {
        Verilated::overWidthError("strum_down");
    }
}
#endif  // VL_DEBUG
