// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vguitar_top.h for the primary calling header

#include "Vguitar_top__pch.h"

VL_ATTR_COLD void Vguitar_top___024root___eval_static(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_static\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP__clk50__0 = vlSelfRef.__VprimaryPorts.clk50;
    vlSelfRef.__Vtrigprevexpr___TOP__rst__0 = vlSelfRef.__VprimaryPorts.rst;
    vlSelfRef.__Vtrigprevexpr___TOP__fret__0 = vlSelfRef.__VprimaryPorts.fret;
    vlSelfRef.__Vtrigprevexpr___TOP__strum_up__0 = vlSelfRef.__VprimaryPorts.strum_up;
    vlSelfRef.__Vtrigprevexpr___TOP__strum_down__0 
        = vlSelfRef.__VprimaryPorts.strum_down;
    vlSelfRef.__Vtrigprevexpr___TOP__clk50__1 = vlSelfRef.__VprimaryPorts.clk50;
}

VL_ATTR_COLD void Vguitar_top___024root___eval_initial(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_initial\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    {
        // Inlined CFunc: _eval_initial__TOP
        VL_READMEM_N(true, 16, 2048, 0, "notes.hex"s
                     ,  &(vlSelfRef.guitar_top__DOT__feeder__DOT__u_rom__DOT__mem)
                     , 0, ~0ULL);
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__stl(const ::VlUnpacked<::QData/*63:0*/, 1> &triggers, const ::std::string &tag);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vguitar_top___024root___trigger_anySet__stl(const ::VlUnpacked<::QData/*63:0*/, 1> &in);
VL_ATTR_COLD void Vguitar_top___024root___stl_comb__TOP__0(Vguitar_top___024root* vlSelf);

VL_ATTR_COLD bool Vguitar_top___024root___eval_stl(Vguitar_top___024root* vlSelf, ::CData/*0:0*/ firstIteration) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_stl\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    ::CData/*0:0*/ __VstlExecute;
    // Body
    vlSelfRef.__VstlTriggered[0U] = ((0xfffffffffffffffeULL 
                                      & vlSelfRef.__VstlTriggered[0U]) 
                                     | (::IData)((::IData)(firstIteration)));
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vguitar_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
    }
#endif
    __VstlExecute = Vguitar_top___024root___trigger_anySet__stl(vlSelfRef.__VstlTriggered);
    if (__VstlExecute) {
        {
            // Inlined CFunc: _eval_body__stl
            if ((((1ULL & vlSelfRef.__VstlTriggered[0U])) != 0ULL)) {
                Vguitar_top___024root___stl_comb__TOP__0(vlSelf);
            }
        }
    }
    return (__VstlExecute);
}

VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__stl(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_dump_triggers__stl\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vguitar_top___024root___dump_triggers__stl(vlSelfRef.__VstlTriggered, "stl"s);
#endif
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__ico(const ::VlUnpacked<::QData/*63:0*/, 2> &triggers, const ::std::string &tag);
#endif  // VL_DEBUG

VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__ico(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_dump_triggers__ico\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vguitar_top___024root___dump_triggers__ico(vlSelfRef.__VicoTriggered, "ico"s);
#endif
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__act(const ::VlUnpacked<::QData/*63:0*/, 1> &triggers, const ::std::string &tag);
#endif  // VL_DEBUG

VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__act(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_dump_triggers__act\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vguitar_top___024root___dump_triggers__act(vlSelfRef.__VactTriggered, "act"s);
#endif
}

VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__nba(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_dump_triggers__nba\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
#ifdef VL_DEBUG
    Vguitar_top___024root___dump_triggers__act(vlSelfRef.__VnbaTriggered, "nba"s);
#endif
}

VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__obs(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_dump_triggers__obs\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__react(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_dump_triggers__react\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

VL_ATTR_COLD void Vguitar_top___024root___eval_final(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___eval_final\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__stl(const ::VlUnpacked<::QData/*63:0*/, 1> &triggers, const ::std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (::IData)(Vguitar_top___024root___trigger_anySet__stl(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (::IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD bool Vguitar_top___024root___trigger_anySet__stl(const ::VlUnpacked<::QData/*63:0*/, 1> &in) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___trigger_anySet__stl\n"); );
    // Locals
    ::IData/*31:0*/ n;
    // Body
    n = 0U;
    do {
        if (in[n]) {
            return (1U);
        }
        n = ((::IData)(1U) + n);
    } while ((1U > n));
    return (0U);
}

VL_ATTR_COLD void Vguitar_top___024root___stl_comb__TOP__0(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___stl_comb__TOP__0\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Locals
    ::CData/*0:0*/ __Vdfg_Regularize_1113;
    __Vdfg_Regularize_1113 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1117;
    __Vdfg_Regularize_1117 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1118;
    __Vdfg_Regularize_1118 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1119;
    __Vdfg_Regularize_1119 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1120;
    __Vdfg_Regularize_1120 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1121;
    __Vdfg_Regularize_1121 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1122;
    __Vdfg_Regularize_1122 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1123;
    __Vdfg_Regularize_1123 = 0;
    ::CData/*0:0*/ __Vdfg_Regularize_1124;
    __Vdfg_Regularize_1124 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1125;
    __Vdfg_Regularize_1125 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1127;
    __Vdfg_Regularize_1127 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1128;
    __Vdfg_Regularize_1128 = 0;
    ::SData/*9:0*/ __Vdfg_Regularize_1130;
    __Vdfg_Regularize_1130 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1131;
    __Vdfg_Regularize_1131 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1132;
    __Vdfg_Regularize_1132 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1133;
    __Vdfg_Regularize_1133 = 0;
    ::CData/*1:0*/ __Vdfg_Regularize_1140;
    __Vdfg_Regularize_1140 = 0;
    ::SData/*10:0*/ __Vdfg_Regularize_1141;
    __Vdfg_Regularize_1141 = 0;
    ::CData/*7:0*/ __Vdfg_Regularize_1142;
    __Vdfg_Regularize_1142 = 0;
    // Body
    vlSelfRef.__VprimaryPorts.hsync = (1U & (~ ((0x0290U 
                                                 <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)) 
                                                & (0x02f0U 
                                                   > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)))));
    vlSelfRef.__VprimaryPorts.vsync = (1U & (~ ((0x01eaU 
                                                 <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                                & (0x01ecU 
                                                   > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)))));
    vlSelfRef.__VprimaryPorts.vga_clk = vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en;
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__new_line 
        = ((0U == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)) 
           & (0U != (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__last_x)));
    vlSelfRef.guitar_top__DOT__hit_unit__DOT__raw_strum 
        = ((::IData)(vlSelfRef.__VprimaryPorts.strum_up) 
           | (::IData)(vlSelfRef.__VprimaryPorts.strum_down));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__frame_tick 
        = ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en) 
           & ((0U == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)) 
              & (0x01e0U == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))));
    vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone 
        = (((((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U])) 
              | ((1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U] 
                               >> 6U))) | ((1U == (3U 
                                                   & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U] 
                                                      >> 4U))) 
                                           | (1U == 
                                              (3U & 
                                               (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[32U] 
                                                >> 2U)))))) 
             << 4U) | ((((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U])) 
                         | ((1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U] 
                                          >> 6U))) 
                            | ((1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U] 
                                             >> 4U))) 
                               | (1U == (3U & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[24U] 
                                               >> 2U)))))) 
                        << 3U) | (((1U == (3U & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U])) 
                                   | ((1U == (3U & 
                                              (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U] 
                                               >> 6U))) 
                                      | ((1U == (3U 
                                                 & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U] 
                                                    >> 4U))) 
                                         | (1U == (3U 
                                                   & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[16U] 
                                                      >> 2U)))))) 
                                  << 2U))) | ((((1U 
                                                 == 
                                                 (3U 
                                                  & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U])) 
                                                | ((1U 
                                                    == 
                                                    (3U 
                                                     & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U] 
                                                        >> 6U))) 
                                                   | ((1U 
                                                       == 
                                                       (3U 
                                                        & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U] 
                                                           >> 4U))) 
                                                      | (1U 
                                                         == 
                                                         (3U 
                                                          & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[8U] 
                                                             >> 2U)))))) 
                                               << 1U) 
                                              | ((1U 
                                                  == 
                                                  (3U 
                                                   & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U] 
                                                      >> 6U))) 
                                                 | ((1U 
                                                     == 
                                                     (3U 
                                                      & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U] 
                                                         >> 4U))) 
                                                    | ((1U 
                                                        == 
                                                        (3U 
                                                         & (vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U] 
                                                            >> 2U))) 
                                                       | (1U 
                                                          == 
                                                          (3U 
                                                           & vlSelfRef.guitar_top__DOT__feeder__DOT__slots[0U])))))));
    vlSelfRef.__VprimaryPorts.blank_n = ((0x01e0U > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                         & (0x0280U 
                                            > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt)));
    __Vdfg_Regularize_1142 = (((0x01e0U > (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                               & (0x01dfU >= (0x000001ffU 
                                              & (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))))
                               ? vlSymsp->vlInst.TOP__highway_pkg.SLOT_LUT
                              [(0x000001ffU & (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))]
                               : 0U);
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[0U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[1U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[2U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[3U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[4U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                          >> 8U));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x[5U] 
        = (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                          >> 8U));
    __Vdfg_Regularize_1121 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1122 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1123 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1124 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                               >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                                                  >> 8U))) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                                                   >> 8U))));
    __Vdfg_Regularize_1113 = ((0x0040U <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                              & (0x01c0U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)));
    __Vdfg_Regularize_1119 = ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                              >= (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
                                                 >> 8U)));
    vlSelfRef.guitar_top__DOT__hit_unit__DOT__fret_match 
        = (((::IData)(vlSelfRef.__VprimaryPorts.fret) 
            == (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone)) 
           & (0U != (::IData)(vlSelfRef.guitar_top__DOT__hit_unit__DOT__note_hit_zone)));
    vlSelfRef.__Vdfg_Regularize_1115 = (0x000000ffU 
                                        & (- (::IData)(
                                                       (((::IData)(__Vdfg_Regularize_1119) 
                                                         & (((0x0040U 
                                                              == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                                             | (0x01c0U 
                                                                == (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt))) 
                                                            & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                               <= 
                                                               (0x000003ffU 
                                                                & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                                                                   >> 8U))))) 
                                                        | ((((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                             == 
                                                             (0x000003ffU 
                                                              & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ 
                                                                 >> 8U))) 
                                                            | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                == 
                                                                (0x000003ffU 
                                                                 & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ 
                                                                    >> 8U))) 
                                                               | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                   == 
                                                                   (0x000003ffU 
                                                                    & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ 
                                                                       >> 8U))) 
                                                                  | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                      == 
                                                                      (0x000003ffU 
                                                                       & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                                                                          >> 8U))) 
                                                                     | (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                         == 
                                                                         (0x000003ffU 
                                                                          & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ 
                                                                             >> 8U))) 
                                                                        | ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                           == 
                                                                           (0x000003ffU 
                                                                            & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ 
                                                                               >> 8U)))))))) 
                                                           & (::IData)(__Vdfg_Regularize_1113))))));
    __Vdfg_Regularize_1120 = ((::IData)(__Vdfg_Regularize_1119) 
                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                 < (0x000003ffU & (vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ 
                                                   >> 8U))));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__in_highway 
        = (((::IData)(__Vdfg_Regularize_1120) | ((::IData)(__Vdfg_Regularize_1121) 
                                                 | ((::IData)(__Vdfg_Regularize_1122) 
                                                    | ((::IData)(__Vdfg_Regularize_1123) 
                                                       | (::IData)(__Vdfg_Regularize_1124))))) 
           & (::IData)(__Vdfg_Regularize_1113));
    vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx 
        = ((- (::IData)((1U & (~ (::IData)(__Vdfg_Regularize_1120))))) 
           & (((::IData)(__Vdfg_Regularize_1121) ? 1U
                : ((::IData)(__Vdfg_Regularize_1122)
                    ? 2U : ((::IData)(__Vdfg_Regularize_1123)
                             ? 3U : (4U & (- (::IData)((::IData)(__Vdfg_Regularize_1124))))))) 
              & (- (::IData)((::IData)(__Vdfg_Regularize_1113)))));
    __Vdfg_Regularize_1117 = ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__in_highway) 
                              & ((0x01c0U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)) 
                                 & (((4U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)) 
                                     && (1U & ((::IData)(vlSelfRef.__VprimaryPorts.fret) 
                                               >> (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)))) 
                                    & (0x0180U <= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt)))));
    if ((4U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx))) {
        __Vdfg_Regularize_1131 = vlSymsp->vlInst.TOP__highway_pkg.LANE_R
            [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx];
        __Vdfg_Regularize_1132 = vlSymsp->vlInst.TOP__highway_pkg.LANE_G
            [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx];
        __Vdfg_Regularize_1133 = vlSymsp->vlInst.TOP__highway_pkg.LANE_B
            [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx];
    } else {
        __Vdfg_Regularize_1131 = 0U;
        __Vdfg_Regularize_1132 = 0U;
        __Vdfg_Regularize_1133 = 0U;
    }
    __Vdfg_Regularize_1141 = (0x000007ffU & ((0x000000ffU 
                                              & ((::IData)(__Vdfg_Regularize_1142) 
                                                 << 1U)) 
                                             + ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx) 
                                                << 8U)));
    __Vdfg_Regularize_1125 = ((5U >= (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx))
                               ? vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x
                              [vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx]
                               : 0U);
    __Vdfg_Regularize_1140 = (((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__in_highway) 
                               & ((0x04ffU >= (::IData)(__Vdfg_Regularize_1141)) 
                                  & ((::IData)(__Vdfg_Regularize_1142) 
                                     >> 7U))) ? (3U 
                                                 & (((0U 
                                                      == 
                                                      (0x0000001fU 
                                                       & (::IData)(__Vdfg_Regularize_1141)))
                                                      ? 0U
                                                      : 
                                                     (vlSelfRef.guitar_top__DOT__feeder__DOT__slots
                                                      [
                                                      (((::IData)(1U) 
                                                        + (::IData)(__Vdfg_Regularize_1141)) 
                                                       >> 5U)] 
                                                      << 
                                                      ((::IData)(0x00000020U) 
                                                       - 
                                                       (0x0000001fU 
                                                        & (::IData)(__Vdfg_Regularize_1141))))) 
                                                    | (vlSelfRef.guitar_top__DOT__feeder__DOT__slots
                                                       [
                                                       ((::IData)(__Vdfg_Regularize_1141) 
                                                        >> 5U)] 
                                                       >> 
                                                       (0x0000001fU 
                                                        & (::IData)(__Vdfg_Regularize_1141)))))
                               : 0U);
    __Vdfg_Regularize_1127 = (0x000003ffU & (((5U >= 
                                               (7U 
                                                & ((::IData)(1U) 
                                                   + (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx))))
                                               ? vlSelfRef.guitar_top__DOT__draw_unit__DOT__edge_x
                                              [(7U 
                                                & ((::IData)(1U) 
                                                   + (::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__lane_idx)))]
                                               : 0U) 
                                             - (::IData)(__Vdfg_Regularize_1125)));
    __Vdfg_Regularize_1130 = ((0U == ((::IData)(__Vdfg_Regularize_1127) 
                                      >> 3U)) ? 1U : 
                              ((::IData)(__Vdfg_Regularize_1127) 
                               >> 3U));
    __Vdfg_Regularize_1128 = (0x000003ffU & ((::IData)(__Vdfg_Regularize_1125) 
                                             + ((::IData)(__Vdfg_Regularize_1127) 
                                                >> 1U)));
    __Vdfg_Regularize_1118 = (0x000000ffU & (- (::IData)(
                                                         ((2U 
                                                           == (::IData)(__Vdfg_Regularize_1140)) 
                                                          & (((0x000003ffU 
                                                               & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                  + (::IData)(__Vdfg_Regularize_1130))) 
                                                              >= (::IData)(__Vdfg_Regularize_1128)) 
                                                             & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt) 
                                                                <= 
                                                                (0x000003ffU 
                                                                 & ((::IData)(__Vdfg_Regularize_1130) 
                                                                    + (::IData)(__Vdfg_Regularize_1128)))))))));
    if ((1U == (::IData)(__Vdfg_Regularize_1140))) {
        vlSelfRef.__Vdfg_Regularize_1134 = __Vdfg_Regularize_1131;
        vlSelfRef.__Vdfg_Regularize_1135 = __Vdfg_Regularize_1132;
        vlSelfRef.__Vdfg_Regularize_1136 = __Vdfg_Regularize_1133;
    } else {
        vlSelfRef.__Vdfg_Regularize_1134 = (((::IData)(__Vdfg_Regularize_1131) 
                                             >> 1U) 
                                            & (::IData)(__Vdfg_Regularize_1118));
        vlSelfRef.__Vdfg_Regularize_1135 = (((::IData)(__Vdfg_Regularize_1132) 
                                             >> 1U) 
                                            & (::IData)(__Vdfg_Regularize_1118));
        vlSelfRef.__Vdfg_Regularize_1136 = (((::IData)(__Vdfg_Regularize_1133) 
                                             >> 1U) 
                                            & (::IData)(__Vdfg_Regularize_1118));
    }
    vlSelfRef.__Vdfg_Regularize_1139 = (0x000001ffU 
                                        & ((0x000001fcU 
                                            & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt) 
                                               << 2U)) 
                                           + (::IData)(vlSelfRef.__Vdfg_Regularize_1134)));
    vlSelfRef.__Vdfg_Regularize_1137 = (0x000001ffU 
                                        & ((::IData)(vlSelfRef.__Vdfg_Regularize_1135) 
                                           + (0x000001fcU 
                                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt) 
                                                 << 2U))));
    vlSelfRef.__Vdfg_Regularize_1138 = (0x000001ffU 
                                        & ((::IData)(vlSelfRef.__Vdfg_Regularize_1136) 
                                           + (0x000001fcU 
                                              & ((::IData)(vlSelfRef.guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt) 
                                                 << 2U))));
    vlSelfRef.__VprimaryPorts.r = (0x000000ffU & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                  & (((::IData)(__Vdfg_Regularize_1117)
                                                       ? 
                                                      ((::IData)(vlSelfRef.__Vdfg_Regularize_1139) 
                                                       | (- (::IData)(
                                                                      (1U 
                                                                       & ((::IData)(vlSelfRef.__Vdfg_Regularize_1139) 
                                                                          >> 8U)))))
                                                       : (::IData)(vlSelfRef.__Vdfg_Regularize_1134)) 
                                                     | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
    vlSelfRef.__VprimaryPorts.g = (0x000000ffU & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                  & (((::IData)(__Vdfg_Regularize_1117)
                                                       ? 
                                                      ((::IData)(vlSelfRef.__Vdfg_Regularize_1137) 
                                                       | (- (::IData)(
                                                                      (1U 
                                                                       & ((::IData)(vlSelfRef.__Vdfg_Regularize_1137) 
                                                                          >> 8U)))))
                                                       : (::IData)(vlSelfRef.__Vdfg_Regularize_1135)) 
                                                     | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
    vlSelfRef.__VprimaryPorts.b = (0x000000ffU & ((- (::IData)((::IData)(vlSelfRef.__VprimaryPorts.blank_n))) 
                                                  & (((::IData)(__Vdfg_Regularize_1117)
                                                       ? 
                                                      ((::IData)(vlSelfRef.__Vdfg_Regularize_1138) 
                                                       | (- (::IData)(
                                                                      (1U 
                                                                       & ((::IData)(vlSelfRef.__Vdfg_Regularize_1138) 
                                                                          >> 8U)))))
                                                       : (::IData)(vlSelfRef.__Vdfg_Regularize_1136)) 
                                                     | (::IData)(vlSelfRef.__Vdfg_Regularize_1115))));
}

bool Vguitar_top___024root___trigger_anySet__ico(const ::VlUnpacked<::QData/*63:0*/, 2> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__ico(const ::VlUnpacked<::QData/*63:0*/, 2> &triggers, const ::std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___dump_triggers__ico\n"); );
    // Body
    if ((1U & (~ (::IData)(Vguitar_top___024root___trigger_anySet__ico(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (::IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @( clk50)\n");
    }
    if ((1U & (::IData)((triggers[0U] >> 1U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 1 is active: @( rst)\n");
    }
    if ((1U & (::IData)((triggers[0U] >> 2U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 2 is active: @( fret)\n");
    }
    if ((1U & (::IData)((triggers[0U] >> 3U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 3 is active: @( strum_up)\n");
    }
    if ((1U & (::IData)((triggers[0U] >> 4U)))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 4 is active: @( strum_down)\n");
    }
    if ((1U & (::IData)(triggers[1U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 64 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

bool Vguitar_top___024root___trigger_anySet__act(const ::VlUnpacked<::QData/*63:0*/, 1> &in);

#ifdef VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___dump_triggers__act(const ::VlUnpacked<::QData/*63:0*/, 1> &triggers, const ::std::string &tag) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (::IData)(Vguitar_top___024root___trigger_anySet__act(triggers))))) {
        VL_DBG_MSGS("         No '" + tag + "' region triggers active\n");
    }
    if ((1U & (::IData)(triggers[0U]))) {
        VL_DBG_MSGS("         '" + tag + "' region trigger index 0 is active: @(posedge clk50)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vguitar_top___024root___ctor_var_reset(Vguitar_top___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vguitar_top___024root___ctor_var_reset\n"); );
    Vguitar_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->vlNamep);
    vlSelf->__VprimaryPorts.clk50 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 194302167662576260ull);
    vlSelf->__VprimaryPorts.rst = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18209466448985614591ull);
    vlSelf->__VprimaryPorts.fret = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 15528144517927124986ull);
    vlSelf->__VprimaryPorts.strum_up = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 767927253429866903ull);
    vlSelf->__VprimaryPorts.strum_down = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 770172443095719807ull);
    vlSelf->__VprimaryPorts.hsync = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2999247747110030874ull);
    vlSelf->__VprimaryPorts.vsync = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18337175696363507471ull);
    vlSelf->__VprimaryPorts.vga_clk = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12881697277282983503ull);
    vlSelf->__VprimaryPorts.blank_n = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17421714457028131053ull);
    vlSelf->__VprimaryPorts.r = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 16978132545290669629ull);
    vlSelf->__VprimaryPorts.g = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 13110760720460257827ull);
    vlSelf->__VprimaryPorts.b = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 16900879642891266615ull);
    vlSelf->__VprimaryPorts.score = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 7812189054279681266ull);
    VL_SCOPED_RAND_RESET_W(1280, vlSelf->guitar_top__DOT__feeder__DOT__slots, __VscopeHash, 18126348872124794734ull);
    vlSelf->guitar_top__DOT__feeder__DOT__frame_count = VL_SCOPED_RAND_RESET_I(15, __VscopeHash, 3729058577261706311ull);
    vlSelf->guitar_top__DOT__feeder__DOT__addr = VL_SCOPED_RAND_RESET_I(11, __VscopeHash, 1813033729256985311ull);
    for (int __Vi0 = 0; __Vi0 < 5; ++__Vi0) {
        vlSelf->guitar_top__DOT__feeder__DOT__note_count[__Vi0] = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 2417310572129023490ull);
    }
    for (int __Vi0 = 0; __Vi0 < 5; ++__Vi0) {
        vlSelf->guitar_top__DOT__feeder__DOT__note_start[__Vi0] = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 12195779758329100851ull);
    }
    for (int __Vi0 = 0; __Vi0 < 5; ++__Vi0) {
        vlSelf->guitar_top__DOT__feeder__DOT__note_ptr[__Vi0] = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 7630093408463061161ull);
    }
    vlSelf->guitar_top__DOT__feeder__DOT__state = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 2753211012352837996ull);
    vlSelf->guitar_top__DOT__feeder__DOT__hdr_idx = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 2120112518395618944ull);
    vlSelf->guitar_top__DOT__feeder__DOT__lane = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 3670043431267744718ull);
    vlSelf->guitar_top__DOT__feeder__DOT__in_hold = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 6222314595646222173ull);
    vlSelf->guitar_top__DOT__feeder__DOT__u_rom__DOT__dout = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 6382087815278193562ull);
    for (int __Vi0 = 0; __Vi0 < 2048; ++__Vi0) {
        vlSelf->guitar_top__DOT__feeder__DOT__u_rom__DOT__mem[__Vi0] = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 8433533753971010147ull);
    }
    vlSelf->guitar_top__DOT__draw_unit__DOT__last_x = VL_SCOPED_RAND_RESET_I(10, __VscopeHash, 8973419022681328067ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__new_line = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12665249852977747414ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__ = VL_SCOPED_RAND_RESET_I(20, __VscopeHash, 11484236203717905148ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__ = VL_SCOPED_RAND_RESET_I(20, __VscopeHash, 1224046862513631831ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__ = VL_SCOPED_RAND_RESET_I(20, __VscopeHash, 13742285871890434038ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__ = VL_SCOPED_RAND_RESET_I(20, __VscopeHash, 5325175013359905219ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__ = VL_SCOPED_RAND_RESET_I(20, __VscopeHash, 15771335832465672385ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__ = VL_SCOPED_RAND_RESET_I(20, __VscopeHash, 7791098994556665652ull);
    for (int __Vi0 = 0; __Vi0 < 6; ++__Vi0) {
        vlSelf->guitar_top__DOT__draw_unit__DOT__edge_x[__Vi0] = VL_SCOPED_RAND_RESET_I(10, __VscopeHash, 2406660163254657656ull);
    }
    vlSelf->guitar_top__DOT__draw_unit__DOT__in_highway = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6640547586088008915ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__lane_idx = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 3617091046578480261ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__frame_tick = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11019751848026862383ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17637831353476329384ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt = VL_SCOPED_RAND_RESET_I(10, __VscopeHash, 2476245224675523491ull);
    vlSelf->guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt = VL_SCOPED_RAND_RESET_I(10, __VscopeHash, 8135284884998871216ull);
    vlSelf->guitar_top__DOT__hit_unit__DOT__raw_strum = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12907388203519370208ull);
    vlSelf->guitar_top__DOT__hit_unit__DOT__strum_prev = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11988840359712188251ull);
    vlSelf->guitar_top__DOT__hit_unit__DOT__strum_pending = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17453313194250099707ull);
    vlSelf->guitar_top__DOT__hit_unit__DOT__note_hit_zone = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 5238731153028419920ull);
    vlSelf->guitar_top__DOT__hit_unit__DOT__state = VL_SCOPED_RAND_RESET_I(2, __VscopeHash, 9655713915187126294ull);
    vlSelf->guitar_top__DOT__hit_unit__DOT__fret_match = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9981565259497972504ull);
    vlSelf->__Vdfg_Regularize_1115 = 0;
    vlSelf->__Vdfg_Regularize_1134 = 0;
    vlSelf->__Vdfg_Regularize_1135 = 0;
    vlSelf->__Vdfg_Regularize_1136 = 0;
    vlSelf->__Vdfg_Regularize_1137 = 0;
    vlSelf->__Vdfg_Regularize_1138 = 0;
    vlSelf->__Vdfg_Regularize_1139 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VstlTriggered[__Vi0] = 0;
    }
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        vlSelf->__VicoTriggered[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__clk50__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__rst__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__fret__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__strum_up__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__strum_down__0 = 0;
    vlSelf->__VicoDidInit = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VactTriggered[__Vi0] = 0;
    }
    vlSelf->__Vtrigprevexpr___TOP__clk50__1 = 0;
    for (int __Vi0 = 0; __Vi0 < 1; ++__Vi0) {
        vlSelf->__VnbaTriggered[__Vi0] = 0;
    }
}
