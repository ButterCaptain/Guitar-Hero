// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vguitar_top.h for the primary calling header

#include "Vguitar_top__pch.h"

void Vguitar_top___024root___ctor_var_reset(Vguitar_top___024root* vlSelf);

void Vguitar_top___024root__ctor(Vguitar_top___024root* vlSelf, Vguitar_top__Syms* symsp, const char* namep) {
    vlSelf->vlSymsp = symsp;
    vlSelf->vlNamep = strdup(namep);
    // Construct members
    // Reset structure values
    Vguitar_top___024root___ctor_var_reset(vlSelf);
}

Vguitar_top___024root::Vguitar_top___024root(Vguitar_top__Syms* symsp, const char* namep) {
    Vguitar_top___024root__ctor(this, symsp, namep);
}

void Vguitar_top___024root__dtor(Vguitar_top___024root* vlSelf) {
    // Destroy members
    VL_DO_DANGLING(std::free(const_cast<char*>(vlSelf->vlNamep)), vlSelf->vlNamep);
}

Vguitar_top___024root::~Vguitar_top___024root() {
    Vguitar_top___024root__dtor(this);
}
