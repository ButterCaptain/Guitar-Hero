// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VGUITAR_TOP__SYMS_H_
#define VERILATED_VGUITAR_TOP__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vguitar_top.h"

// INCLUDE MODULE CLASSES
#include "Vguitar_top___024root.h"
#include "Vguitar_top_highway_pkg.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES) Vguitar_top__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vguitar_top* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool& __Vm_didInit;

    // MODULE INSTANCE STATE
    union {
        struct {
            Vguitar_top___024root          TOP;
            Vguitar_top_highway_pkg        TOP__highway_pkg;
        } vlInst;
    };

    // CONSTRUCTORS
    Vguitar_top__Syms(VerilatedContext* contextp, const char* namep, Vguitar_top* modelp);
    ~Vguitar_top__Syms();

    // METHODS
    const char* name() const { return vlInst.TOP.vlNamep; }
};

#endif  // guard
