verilated.o: \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated.cpp \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_config.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilatedos.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_types.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_funcs.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_imp.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_syms.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_sym_props.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_threads.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_trace.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilatedos_c.h
