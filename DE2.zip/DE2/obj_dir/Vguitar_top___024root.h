// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vguitar_top.h for the primary calling header

#ifndef VERILATED_VGUITAR_TOP___024ROOT_H_
#define VERILATED_VGUITAR_TOP___024ROOT_H_  // guard

#include "verilated.h"
class Vguitar_top_highway_pkg;


class Vguitar_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vguitar_top___024root final {
  public:
    // CELLS
    Vguitar_top_highway_pkg* __PVT__highway_pkg;

    // TOP LEVEL PORTS
    union {
        struct {
            VL_IN8(clk50,0,0);
            VL_IN8(rst,0,0);
            VL_IN8(fret,4,0);
            VL_IN8(strum_up,0,0);
            VL_IN8(strum_down,0,0);
            VL_OUT8(hsync,0,0);
            VL_OUT8(vsync,0,0);
            VL_OUT8(vga_clk,0,0);
            VL_OUT8(blank_n,0,0);
            VL_OUT8(r,7,0);
            VL_OUT8(g,7,0);
            VL_OUT8(b,7,0);
            VL_OUT16(score,15,0);
        } __VprimaryPorts;
    };

    // TRIVIALLY CONSTRUCTIBLE STATE
    ::VlWide<40>/*1279:0*/ guitar_top__DOT__feeder__DOT__slots;
    ::CData/*2:0*/ guitar_top__DOT__feeder__DOT__state;
    ::CData/*3:0*/ guitar_top__DOT__feeder__DOT__hdr_idx;
    ::CData/*2:0*/ guitar_top__DOT__feeder__DOT__lane;
    ::CData/*4:0*/ guitar_top__DOT__feeder__DOT__in_hold;
    ::CData/*0:0*/ guitar_top__DOT__draw_unit__DOT__new_line;
    ::CData/*0:0*/ guitar_top__DOT__draw_unit__DOT__in_highway;
    ::CData/*2:0*/ guitar_top__DOT__draw_unit__DOT__lane_idx;
    ::CData/*0:0*/ guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__frame_tick;
    ::CData/*0:0*/ guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__pix_en;
    ::CData/*0:0*/ guitar_top__DOT__hit_unit__DOT__raw_strum;
    ::CData/*0:0*/ guitar_top__DOT__hit_unit__DOT__strum_prev;
    ::CData/*0:0*/ guitar_top__DOT__hit_unit__DOT__strum_pending;
    ::CData/*4:0*/ guitar_top__DOT__hit_unit__DOT__note_hit_zone;
    ::CData/*1:0*/ guitar_top__DOT__hit_unit__DOT__state;
    ::CData/*0:0*/ guitar_top__DOT__hit_unit__DOT__fret_match;
    ::CData/*7:0*/ __Vdfg_Regularize_1115;
    ::CData/*7:0*/ __Vdfg_Regularize_1134;
    ::CData/*7:0*/ __Vdfg_Regularize_1135;
    ::CData/*7:0*/ __Vdfg_Regularize_1136;
    ::CData/*0:0*/ __Vtrigprevexpr___TOP__clk50__0;
    ::CData/*0:0*/ __Vtrigprevexpr___TOP__rst__0;
    ::CData/*4:0*/ __Vtrigprevexpr___TOP__fret__0;
    ::CData/*0:0*/ __Vtrigprevexpr___TOP__strum_up__0;
    ::CData/*0:0*/ __Vtrigprevexpr___TOP__strum_down__0;
    ::CData/*0:0*/ __VicoDidInit;
    ::CData/*0:0*/ __Vtrigprevexpr___TOP__clk50__1;
    ::SData/*14:0*/ guitar_top__DOT__feeder__DOT__frame_count;
    ::SData/*10:0*/ guitar_top__DOT__feeder__DOT__addr;
    ::SData/*15:0*/ guitar_top__DOT__feeder__DOT__u_rom__DOT__dout;
    ::SData/*9:0*/ guitar_top__DOT__draw_unit__DOT__last_x;
    ::SData/*9:0*/ guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__h_cnt;
    ::SData/*9:0*/ guitar_top__DOT__draw_unit__DOT__sync_unit__DOT__v_cnt;
    ::SData/*8:0*/ __Vdfg_Regularize_1137;
    ::SData/*8:0*/ __Vdfg_Regularize_1138;
    ::SData/*8:0*/ __Vdfg_Regularize_1139;
    ::IData/*19:0*/ guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__0__KET__;
    ::IData/*19:0*/ guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__1__KET__;
    ::IData/*19:0*/ guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__2__KET__;
    ::IData/*19:0*/ guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__3__KET__;
    ::IData/*19:0*/ guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__4__KET__;
    ::IData/*19:0*/ guitar_top__DOT__draw_unit__DOT__edge_acc__BRA__5__KET__;
    ::VlUnpacked<::SData/*15:0*/, 5> guitar_top__DOT__feeder__DOT__note_count;
    ::VlUnpacked<::SData/*15:0*/, 5> guitar_top__DOT__feeder__DOT__note_start;
    ::VlUnpacked<::SData/*15:0*/, 5> guitar_top__DOT__feeder__DOT__note_ptr;
    ::VlUnpacked<::SData/*15:0*/, 2048> guitar_top__DOT__feeder__DOT__u_rom__DOT__mem;
    ::VlUnpacked<::SData/*9:0*/, 6> guitar_top__DOT__draw_unit__DOT__edge_x;
    ::VlUnpacked<::QData/*63:0*/, 1> __VstlTriggered;
    ::VlUnpacked<::QData/*63:0*/, 2> __VicoTriggered;
    ::VlUnpacked<::QData/*63:0*/, 1> __VactTriggered;
    ::VlUnpacked<::QData/*63:0*/, 1> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vguitar_top__Syms* vlSymsp;
    const char* vlNamep;

    // CONSTRUCTORS
    Vguitar_top___024root(Vguitar_top__Syms* symsp, const char* namep);
    ~Vguitar_top___024root();
    VL_UNCOPYABLE(Vguitar_top___024root);
    VL_UNMOVABLE(Vguitar_top___024root);

    // INTERNAL METHODS
};


#endif  // guard
