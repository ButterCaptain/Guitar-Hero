verilated_threads.o: \
  /Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/SDKSettings.json \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_threads.cpp \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilatedos.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_threads.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_config.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_types.h \
  /Users/wyattbordeaux/Utils/oss-cad-suite/share/verilator/include/verilated_funcs.h
