// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vguitar_top__pch.h"


void Vguitar_top__Syms__ctor(Vguitar_top__Syms* vlSymsp, const char* namep) {
    // Setup top module instance
    VL_INPLACE_CONSTRUCT(vlSymsp->vlInst.TOP, vlSymsp, namep);
    // Check resources
    Verilated::stackCheck(731);
    // Setup sub module instances
    VL_INPLACE_CONSTRUCT(vlSymsp->vlInst.TOP__highway_pkg, vlSymsp, "highway_pkg");
    // Configure time unit / time precision
    vlSymsp->_vm_contextp__->timeunit(-12);
    vlSymsp->_vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    vlSymsp->vlInst.TOP.__PVT__highway_pkg = &vlSymsp->vlInst.TOP__highway_pkg;
}

Vguitar_top__Syms::Vguitar_top__Syms(VerilatedContext* contextp, const char* namep, Vguitar_top* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    , __Vm_didInit{modelp->m_didInit}
{
    Vguitar_top__Syms__ctor(this, namep);
}

void Vguitar_top__Syms__dtor(Vguitar_top__Syms* vlSymsp) {
    // Tear down scopes
    // Tear down sub module instances
    VL_INPLACE_DESTRUCT(vlSymsp->vlInst.TOP__highway_pkg);
    // Tear down top module instance
    VL_INPLACE_DESTRUCT(vlSymsp->vlInst.TOP);
}

Vguitar_top__Syms::~Vguitar_top__Syms() {
    Vguitar_top__Syms__dtor(this);
}
