// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vguitar_top__pch.h"

//============================================================
// Constructors

Vguitar_top::Vguitar_top(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vguitar_top__Syms(contextp(), _vcname__, this)}
    , m_evalLoop{*this, /*convergeLimit:*/ 10000}
    , clk50{vlSymsp->vlInst.TOP.__VprimaryPorts.clk50}
    , rst{vlSymsp->vlInst.TOP.__VprimaryPorts.rst}
    , fret{vlSymsp->vlInst.TOP.__VprimaryPorts.fret}
    , strum_up{vlSymsp->vlInst.TOP.__VprimaryPorts.strum_up}
    , strum_down{vlSymsp->vlInst.TOP.__VprimaryPorts.strum_down}
    , hsync{vlSymsp->vlInst.TOP.__VprimaryPorts.hsync}
    , vsync{vlSymsp->vlInst.TOP.__VprimaryPorts.vsync}
    , vga_clk{vlSymsp->vlInst.TOP.__VprimaryPorts.vga_clk}
    , blank_n{vlSymsp->vlInst.TOP.__VprimaryPorts.blank_n}
    , r{vlSymsp->vlInst.TOP.__VprimaryPorts.r}
    , g{vlSymsp->vlInst.TOP.__VprimaryPorts.g}
    , b{vlSymsp->vlInst.TOP.__VprimaryPorts.b}
    , score{vlSymsp->vlInst.TOP.__VprimaryPorts.score}
    , __PVT__highway_pkg{vlSymsp->vlInst.TOP.__PVT__highway_pkg}
    , rootp{&(vlSymsp->vlInst.TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vguitar_top::Vguitar_top(const char* _vcname__)
    : Vguitar_top(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vguitar_top::~Vguitar_top() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vguitar_top___024root___eval_debug_assertions(Vguitar_top___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD void Vguitar_top___024root___eval_static(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_initial(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD bool Vguitar_top___024root___eval_stl(Vguitar_top___024root* vlSelf, ::CData/*0:0*/ firstIteration);
void Vguitar_top___024root___eval_sample(Vguitar_top___024root* vlSelf);
bool Vguitar_top___024root___eval_ico(Vguitar_top___024root* vlSelf, ::CData/*0:0*/ firstIteration);
bool Vguitar_top___024root___eval_act(Vguitar_top___024root* vlSelf);
bool Vguitar_top___024root___eval_inact(Vguitar_top___024root* vlSelf);
bool Vguitar_top___024root___eval_nba(Vguitar_top___024root* vlSelf);
bool Vguitar_top___024root___eval_obs(Vguitar_top___024root* vlSelf);
bool Vguitar_top___024root___eval_react(Vguitar_top___024root* vlSelf);
void Vguitar_top___024root___eval_postponed(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_final(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__stl(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__ico(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__act(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__nba(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__obs(Vguitar_top___024root* vlSelf);
VL_ATTR_COLD void Vguitar_top___024root___eval_dump_triggers__react(Vguitar_top___024root* vlSelf);

void Vguitar_top::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vguitar_top::eval_step\n"); );
    m_evalLoop.eval();
}

void Vguitar_top::evalBegin() {
#ifdef VL_DEBUG
    // Debug assertions
    Vguitar_top___024root___eval_debug_assertions(&(vlSymsp->vlInst.TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
}

void Vguitar_top::evalEnd() {
    // Evaluate cleanup
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

void Vguitar_top::evalStatic() {
    Vguitar_top___024root___eval_static(&(vlSymsp->vlInst.TOP));
}

void Vguitar_top::evalInitial() {
    Vguitar_top___024root___eval_initial(&(vlSymsp->vlInst.TOP));
}

bool Vguitar_top::evalStl(bool firstIteration) {
    return Vguitar_top___024root___eval_stl(&(vlSymsp->vlInst.TOP), firstIteration);
}

void Vguitar_top::evalSample() {
    Vguitar_top___024root___eval_sample(&(vlSymsp->vlInst.TOP));
}

bool Vguitar_top::evalIco(bool firstIteration) {
    return Vguitar_top___024root___eval_ico(&(vlSymsp->vlInst.TOP), firstIteration);
}

bool Vguitar_top::evalAct() {
    return Vguitar_top___024root___eval_act(&(vlSymsp->vlInst.TOP));
}

bool Vguitar_top::evalInact() {
    return Vguitar_top___024root___eval_inact(&(vlSymsp->vlInst.TOP));
}

bool Vguitar_top::evalNba() {
    return Vguitar_top___024root___eval_nba(&(vlSymsp->vlInst.TOP));
}

bool Vguitar_top::evalObs() {
    return Vguitar_top___024root___eval_obs(&(vlSymsp->vlInst.TOP));
}

bool Vguitar_top::evalReact() {
    return Vguitar_top___024root___eval_react(&(vlSymsp->vlInst.TOP));
}

void Vguitar_top::evalPostponed() {
    Vguitar_top___024root___eval_postponed(&(vlSymsp->vlInst.TOP));
}

void Vguitar_top::evalFinal() {
    Vguitar_top___024root___eval_final(&(vlSymsp->vlInst.TOP));
}

VL_ATTR_COLD void Vguitar_top::dumpTriggersStl() {
    Vguitar_top___024root___eval_dump_triggers__stl(&(vlSymsp->vlInst.TOP));
}

VL_ATTR_COLD void Vguitar_top::dumpTriggersIco() {
    Vguitar_top___024root___eval_dump_triggers__ico(&(vlSymsp->vlInst.TOP));
}

VL_ATTR_COLD void Vguitar_top::dumpTriggersAct() {
    Vguitar_top___024root___eval_dump_triggers__act(&(vlSymsp->vlInst.TOP));
}

VL_ATTR_COLD void Vguitar_top::dumpTriggersNba() {
    Vguitar_top___024root___eval_dump_triggers__nba(&(vlSymsp->vlInst.TOP));
}

VL_ATTR_COLD void Vguitar_top::dumpTriggersObs() {
    Vguitar_top___024root___eval_dump_triggers__obs(&(vlSymsp->vlInst.TOP));
}

VL_ATTR_COLD void Vguitar_top::dumpTriggersReact() {
    Vguitar_top___024root___eval_dump_triggers__react(&(vlSymsp->vlInst.TOP));
}

//============================================================
// Events and timing
bool Vguitar_top::eventsPending() { return false; }

uint64_t Vguitar_top::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vguitar_top::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

VL_ATTR_COLD void Vguitar_top::final() {
    contextp()->executingFinal(true);
    evalFinal();
    contextp()->executingFinal(false);
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vguitar_top::hierName() const { return vlSymsp->name(); }
const char* Vguitar_top::modelName() const { return "Vguitar_top"; }
unsigned Vguitar_top::threads() const { return 1; }
void Vguitar_top::prepareClone() const { contextp()->prepareClone(); }
void Vguitar_top::atClone() const {
    contextp()->threadPoolpOnClone();
}
