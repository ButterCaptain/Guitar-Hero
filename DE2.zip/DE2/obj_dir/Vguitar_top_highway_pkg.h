// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vguitar_top.h for the primary calling header

#ifndef VERILATED_VGUITAR_TOP_HIGHWAY_PKG_H_
#define VERILATED_VGUITAR_TOP_HIGHWAY_PKG_H_  // guard

#include "verilated.h"


class Vguitar_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vguitar_top_highway_pkg final {
  public:

    // INTERNAL VARIABLES
    Vguitar_top__Syms* vlSymsp;
    const char* vlNamep;

    // PARAMETERS
    static const ::VlUnpacked<::CData/*7:0*/, 5> LANE_R;
    static const ::VlUnpacked<::CData/*7:0*/, 5> LANE_G;
    static const ::VlUnpacked<::CData/*7:0*/, 5> LANE_B;
    static const ::VlUnpacked<::CData/*7:0*/, 480> SLOT_LUT;

    // CONSTRUCTORS
    Vguitar_top_highway_pkg(Vguitar_top__Syms* symsp, const char* namep);
    ~Vguitar_top_highway_pkg();
    VL_UNCOPYABLE(Vguitar_top_highway_pkg);
    VL_UNMOVABLE(Vguitar_top_highway_pkg);

    // INTERNAL METHODS
};


#endif  // guard
